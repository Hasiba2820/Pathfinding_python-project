# Path-Finding-AI-Using-Python
A minimum distance path finding algorithm between two points using modified Dijkstra algorithm. Language used is python and tkinter library is used for user interface.

Adjancy_matrix_gen.py - contain the code for generating adjancy matrix for each 400 points(vertices)

backened.py - contains the logic for genrating minimum path for each source vertex and all vertex(including destination vertex) and also generate parent list

pathAI.py - contain the the code for GUI and interlinks backend with front end 
